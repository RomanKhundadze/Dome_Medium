cd .\SourceCode\
javac -g main.java Playtime.java Medium.java CD.java DVD.java Schallplatte.java LP.java Maxi.java Datenbank.java
java main
cd ..