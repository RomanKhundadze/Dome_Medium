public class Maxi extends Schallplatte{
    public Maxi(String title, String prod, PlayTime playTime, boolean ownMedia, String kommentar, int titleCount){
        super(title, prod, playTime, ownMedia, kommentar, titleCount,45);
    }
}
