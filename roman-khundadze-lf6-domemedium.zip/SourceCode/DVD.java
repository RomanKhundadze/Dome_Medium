public class DVD extends Medium{
    public DVD(String title, String prod, PlayTime playTime, boolean ownMedia, String kommentar){
        super(title, prod, playTime, ownMedia, kommentar);
    }
}